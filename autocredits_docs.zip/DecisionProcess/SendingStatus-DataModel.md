# SendingStatus — DataModel
