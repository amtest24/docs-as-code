# ReceivingADecision — UseCases
