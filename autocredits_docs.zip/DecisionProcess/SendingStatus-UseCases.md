# SendingStatus — UseCases
