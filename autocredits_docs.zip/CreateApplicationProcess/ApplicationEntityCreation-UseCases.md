# ApplicationEntityCreation — UseCases
