# SendApplication — UseCases
