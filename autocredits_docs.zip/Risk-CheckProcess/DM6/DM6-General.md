# DM6 — General
