# DM7 — UseCases
