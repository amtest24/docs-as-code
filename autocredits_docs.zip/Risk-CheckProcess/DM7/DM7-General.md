# DM7 — General
