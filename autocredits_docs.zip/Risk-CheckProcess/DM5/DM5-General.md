# DM5 — General
