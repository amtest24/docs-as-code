# DM3 — General
